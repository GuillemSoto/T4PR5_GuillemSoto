﻿using System.ComponentModel.DataAnnotations;

namespace T5PR1.Models
{
    //any, produccioNeta, consumGasolina, demandaElectrica, produccioDisponible
    public class EnergeticIndicators
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public int Year { get; set; }
        [Required]
        public string NetProduction { get; set; }
        [Required]
        public int GasConsumption { get; set; }
        [Required]
        public int ElectricDemand { get; set; }
        [Required]
        public int AvailableProduction { get; set; }
    }
}
