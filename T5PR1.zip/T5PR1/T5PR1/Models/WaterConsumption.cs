﻿using System.ComponentModel.DataAnnotations;

namespace T5PR1.Models
{
    //id, comarca, municipi, any, consum
    public class WaterConsumption
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public string Region { get; set; }
        [Required]
        public string Town { get; set; }
        [Required]
        public int Year { get; set; }
        [Required]
        public string Consumptions { get; set; }
    }
}
