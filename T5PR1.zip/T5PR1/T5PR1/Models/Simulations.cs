﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace T5PR1.Models
{
    public enum EnergyType
    {
        Solar,
        Eolic,
        Hydraulic
    }
    public class Simulations
    {
        [Key]
        public int Id { get; set; }
        public EnergyType Type { get; set; }
        [Required]
        public float Parameter { get; set; }
        [Required]
        [Range(0.1, 0.3)]
        public float Ratio { get; set; }
        [Required]
        public int GeneratedEnergy { get; set; }
        [Required]
        public decimal KWhCost { get; set; }
        [Required]
        public decimal KWhPrice { get; set; }
        public DateTime SimulationDate { get; set; } = DateTime.Now;
    }
}
