﻿using Microsoft.EntityFrameworkCore;
using T5PR1.Models;

namespace T5PR1.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<Simulations> Simulations { get; set; }
        public DbSet<WaterConsumption> WaterConsumptions { get; set; }
        public DbSet<EnergeticIndicators> EnergeticIndicators { get; set; }
    }

}
