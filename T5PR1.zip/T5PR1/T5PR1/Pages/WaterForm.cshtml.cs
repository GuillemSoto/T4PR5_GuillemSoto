using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using T5PR1.Data;
using T5PR1.Models;

namespace T5PR1.Pages
{
    public class WcFormModel : PageModel
    {
        private readonly ApplicationDbContext _context;
        public WcFormModel(ApplicationDbContext context)
        {
            _context = context;
        }
        public IActionResult OnGet()
        {
            return Page();
        }
        [BindProperty]
        public WaterConsumption water { get; set; }

        public async Task<IActionResult> OnPost()
        {
            try
            {
                _context.WaterConsumptions.Add(water);
                await _context.SaveChangesAsync();
                return RedirectToPage(nameof(WaterConsumption));
            }
            catch (Exception ex)
            {
                return Page();
            }
        }
    }
}
