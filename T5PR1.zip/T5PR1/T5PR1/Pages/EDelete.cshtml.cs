using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using T5PR1.Data;
using T5PR1.Models;

namespace T5PR1.Pages
{
    public class EDeleteModel: PageModel
    {
        private readonly ApplicationDbContext _context;
        public EDeleteModel(ApplicationDbContext context)
        {
            _context = context;
        }
        [BindProperty]
        public EnergeticIndicators energetic { get; set; }
        public async Task<IActionResult> OnGetAsync(int? itemid)
        {
            if (itemid == null || _context.EnergeticIndicators == null)
            {
                return NotFound();
            }
            var energy = await _context.EnergeticIndicators.FirstOrDefaultAsync(s => s.Id == itemid);
            if (energy == null)
            {
                return NotFound();
            }
            energetic = energy;
            return Page();
        }

        public async Task<IActionResult> OnPostAsync(int? itemid)
        {
            if (itemid == null)
            {
                return NotFound();
            }
            var energy = await _context.EnergeticIndicators.FindAsync(itemid);
            if (energy == null)
            {
                return NotFound();
            }
            energetic = energy;
            _context.Remove(energetic);
            await _context.SaveChangesAsync();
            return RedirectToPage(nameof(EnergeticIndicators));
        }
    }
}
