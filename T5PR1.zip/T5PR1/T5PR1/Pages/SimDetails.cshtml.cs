using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using T5PR1.Data;
using T5PR1.Models;

namespace T5PR1.Pages
{
    public class SimDetailsModel : PageModel
    {
        private readonly ApplicationDbContext _context;
        public SimDetailsModel(ApplicationDbContext context)
        {
            _context = context;
        }
        [BindProperty]
        public Simulations simulations { get; set; }
        public async Task<IActionResult> OnGetAsync(int? itemid)
        {
            if (itemid == null || _context.Simulations == null)
            {
                return NotFound();
            }
            var simulation = await _context.Simulations.FirstOrDefaultAsync(s => s.Id == itemid);
            if (simulation == null)
            {
                return NotFound();
            }
            simulations = simulation;
            return Page();
        }
    }
}
