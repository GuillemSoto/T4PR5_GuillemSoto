using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using T5PR1.Data;
using T5PR1.Models;

namespace T5PR1.Pages
{
    public class WcDetailsModel : PageModel
    {
        private readonly ApplicationDbContext _context;
        public WcDetailsModel(ApplicationDbContext context)
        {
            _context = context;
        }
        [BindProperty]
        public WaterConsumption Water { get; set; }
        public async Task<IActionResult> OnGetAsync(int? itemid)
        {
            if (itemid == null || _context.WaterConsumptions == null)
            {
                return NotFound();
            }
            var water = await _context.WaterConsumptions.FirstOrDefaultAsync(s => s.Id == itemid);
            if (water == null)
            {
                return NotFound();
            }
            Water = water;
            return Page();
        }
    }
}
