﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Microsoft.Win32;
using T5PR1.Data;
using T5PR1.Models;

namespace T5PR1.Pages
{
    public class SimulationsModel : PageModel
    {
        private readonly ApplicationDbContext _context;
        public SimulationsModel(ApplicationDbContext context)
        {
            _context = context;
        }
        public List<Simulations> simulations {  get; set; }

        public async Task OnGetAsync()
        {
            if(_context.Simulations != null)
            {
                simulations = await _context.Simulations.ToListAsync();
            }
        }
    }

}
