using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using T5PR1.Data;
using T5PR1.Models;

namespace T5PR1.Pages
{
    public class EFormModel : PageModel
    {
        private readonly ApplicationDbContext _context;
        public EFormModel(ApplicationDbContext context)
        {
            _context = context;
        }
        public IActionResult OnGet()
        {
            return Page();
        }
        [BindProperty]
        public EnergeticIndicators energetic { get; set; }

        public async Task<IActionResult> OnPost()
        {
            try
            {
                _context.Simulations.Add(energetic);
                await _context.SaveChangesAsync();
                return RedirectToPage(nameof(EnergeticIndicators));
            }
            catch (Exception ex)
            {
                return Page();
            }
        }
    }
}
