using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using T5PR1.Data;
using T5PR1.Models;

namespace T5PR1.Pages
{
    public class SimFormModel : PageModel
    {
        private readonly ApplicationDbContext _context;
        public SimFormModel(ApplicationDbContext context)
        {
            _context = context;
        }
        public IActionResult OnGet()
        {
            return Page();
        }
        [BindProperty]
        public Simulations simulations { get; set; }

        public async Task<IActionResult> OnPost()
        {
            try
            {
                _context.Simulations.Add(simulations);
                await _context.SaveChangesAsync();
                return RedirectToPage(nameof(Simulations));
            }
            catch (Exception ex)
            {
                return Page();
            }
        }
    }
}
